# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

Preview video frame filter의 silent failure를 진단 가능하게 만들고 오류 폭주를 방지하라.

## 확인된 코드

`app/video/frame_filter.py::VideoFrameFilterTask.run()`:

- `filter_video_frame()`의 모든 `Exception`을 catch
- 빈 `QImage()`로 대체
- 로그나 error signal 없음

worker가 UI를 죽이지 않는 fallback 자체는 합리적이지만,
NumPy shape, QImage format, memory pressure, unexpected settings bug가 생겨도 사용자는 단순히 프레임이 사라지는 현상만 보게 된다.

## 목표

Preview를 계속 살려두는 현재 fallback을 유지하면서 개발자와 사용자 지원 시 원인을 찾을 수 있게 한다.

## 작업

1. broad catch를 제거하라는 의미가 아니다.
   worker boundary에서는 예외를 막되 `LOGGER`에 진단 정보를 남긴다.
2. frame마다 같은 오류가 반복될 수 있으므로 rate limit / once-per-error-signature를 적용한다.
3. 로그 context:
   - exception type/message
   - filter settings
   - input image size/format
   - generation 식별값은 민감 정보가 아니라면 포함
4. 전체 stack trace는 debug/log file에만 남기고 UI popup을 매 frame 띄우지 않는다.
5. 필요하면 `failed` signal을 추가하되 SourceItem이 한 번만 상태 표시하도록 한다.
6. filter setting validation을 worker 시작 전 강화한다.
7. NumPy 메모리 allocation 실패와 일반 계산 오류의 fallback 메시지를 구분할지 검토한다.
8. 같은 필터가 static image/background와 공유되므로 Preview/Export 시각 결과를 바꾸지 않는다.

## 테스트

- `filter_video_frame` monkeypatch가 exception을 던질 때 task가 crash하지 않음
- empty image result 유지
- 동일 오류 100회 -> 로그 폭주하지 않음
- 다른 오류 signature -> 별도 기록
- owner Canvas가 먼저 삭제된 뒤 `finished.emit` RuntimeError -> 안전
- 정상 filter output pixel regression 유지

## 완료 조건

- silent black/empty frame 문제를 로그만으로 원인 추적 가능.
- 오류가 반복되어도 로그 파일과 UI가 폭주하지 않음.
- 정상 프레임 처리 성능 저하가 유의미하지 않음.
