# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

거대 PySide6 UI 클래스를 기능 단위로 단계적으로 분해하고 상태 소유권을 명확히 하라.

## 근거

기준 트리에서 다음 파일이 매우 크다.

- `app/ui/main_window.py` 약 246 KB
- `app/dialogs/export_preview_dialog.py` 약 179 KB
- `app/canvas/source_item.py` 약 106 KB
- `app/inspector/source_inspector.py` 약 108 KB
- `app/widgets/transition_inspector.py` 약 88 KB

`MainWindow`는 이미 `ProjectController`, `PreviewController`, `ExportOrchestrator`,
`AutosaveController`, `HistoryController`, `AutoMixAnalysisController` 등으로 일부 책임을 분리했다.
또한 `tests/test_architecture.py`가 `app.ui.main_window` 역방향 import 금지와 일부 runtime-state 소유권을 보호한다.

따라서 "새 구조로 전면 재작성"이 아니라 **현재 분리 방향을 이어가는 단계적 리팩터링**이 필요하다.

## 목표

MainWindow와 대형 Dialog/Widget이 UI composition과 signal wiring에 집중하도록 하고,
도메인 상태, 장기 작업, 변환 로직, command orchestration은 테스트 가능한 별도 객체로 옮긴다.

## 1단계: 책임 지도 작성

코드를 수정하기 전에 각 대형 파일의 public/private method를 다음 범주로 분류한다.

- UI 생성/layout
- QAction/menu/shortcut wiring
- Project lifecycle
- Preview lifecycle
- Export lifecycle
- AutoMix lifecycle
- Playlist import/export
- source/layer editing
- settings/update/FFmpeg install
- autosave/recovery
- status/tray/progress
- serialization/helper

"파일 줄 수"가 아니라 상태와 dependency cluster를 기준으로 경계를 찾는다.

## 2단계: MainWindow에서 추가 추출

다음 조건을 만족하는 cluster부터 하나씩 추출한다.

- 독립적인 상태 필드가 3개 이상
- 독립적인 signal wiring이 존재
- 테스트가 MainWindow private field를 직접 만지는 비율이 높음
- I/O 또는 worker lifecycle을 포함함

후보 예:
- update + FFmpeg installation orchestration
- tray/export notification
- panel/layout persistence
- clipboard/source commands
- drag/drop import routing

새 controller는 MainWindow를 import하지 않는다.
필요한 widget/service를 constructor parameter나 작은 protocol 형태로 전달한다.

## 3단계: ExportPreviewDialog 분해

Dialog가 다음을 동시에 담당한다면 분리한다.

- transport/player state
- preview rendering/snapshot
- AutoMix progressive status
- transition details synchronization
- temporary resource lifetime
- track panel UI

우선 non-widget state machine 또는 controller를 추출하고, 최종 QWidget 분할은 그 다음에 한다.

## 4단계: SourceItem / Inspector

- painting
- geometry/hit testing
- content formatting
- media/filter state
- interaction handles
- property editor binding

을 섞지 않도록 pure helper/model을 추출한다.
Preview와 Export가 공유해야 하는 계산은 UI class에 두지 않는다.

## 제약

- `tests/test_architecture.py`의 기존 규칙을 깨지 않는다.
- 새로운 circular import를 만들지 않는다.
- MainWindow를 service locator처럼 넘기지 않는다.
- signal lambda로 owner를 불필요하게 강하게 캡처하지 않는다.
- 한 PR에서 모든 파일을 갈아엎지 않는다.
- UI 픽셀/shortcut/기존 동작은 리팩터링 단계에서 변경하지 않는다.

## 테스트 전략

- 기존 MainWindow 테스트를 동작 단위 controller 테스트로 일부 이동
- 순수 계산은 Qt 없이 테스트
- widget integration 테스트는 최소화
- 새 architecture test:
  - controller -> main_window runtime import 금지
  - renderer/service -> UI import 금지
  - worker ownership이 controller 밖으로 새지 않는지 검사

## 완료 조건

- 최소 2개 이상의 명확한 responsibility cluster가 MainWindow 또는 ExportPreviewDialog에서 분리된다.
- 새 모듈은 독립 단위 테스트를 가진다.
- 기존 UI 동작과 전체 테스트가 유지된다.
- 리팩터링 결과와 남은 후속 분해 후보를 별도 문서에 기록한다.
