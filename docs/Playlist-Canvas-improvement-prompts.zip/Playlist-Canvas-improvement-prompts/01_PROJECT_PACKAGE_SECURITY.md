# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

`.pvsproj` 프로젝트 패키지의 자산 참조 경로를 추출된 안전 자산으로만 제한하라.

## 확인 근거

`app/services/project_service.py`의 `_load_package()`는 ZIP 실제 엔트리를 추출할 때 다음을 이미 잘 처리한다.

- `assets/` 하위 엔트리만 추출
- 빈 경로, `.`, `..` path part 거부
- 자산 개수 제한
- manifest와 thumbnail 크기 제한
- 추출 예상 바이트와 디스크 여유 공간 확인
- 취소 가능한 chunked extraction

하지만 이후 `resolved(raw_path)`에서 manifest 문자열이 `assets/...`로 시작하면,
실제 `extracted_assets`에 없는 경우에도 `cache_root.joinpath(*parts).resolve()`를 fallback으로 반환한다.

따라서 ZIP 안에 실제 자산 엔트리가 없어도 manifest가 예를 들어
`assets/../../outside-file` 같은 경로를 참조하면 cache root 바깥 로컬 경로로 정규화될 수 있는지 검증해야 한다.

## 목표

패키지 내부 경로는 **ZIP에서 검증 후 실제로 추출된 자산의 정확한 archive path**일 때만 로컬 파일로 변환한다.
손상되거나 악의적인 내부 참조가 임의의 로컬 경로를 가리키지 못하게 한다.

## 구현 요구사항

1. `_load_package()`의 manifest 자산 참조 해석을 별도 함수로 추출한다.
2. `assets/...`로 보이는 값은 다음을 모두 만족해야 한다.
   - POSIX path로 정상 파싱 가능
   - `parts[0] == "assets"`
   - `.`, `..`, 빈 component 없음
   - absolute path 아님
   - `extracted_assets`에 정확히 존재
3. 패키지 모드에서 `assets/...`인데 실제 추출된 엔트리가 없으면 조용히 로컬 fallback하지 않는다.
   - 명확한 `ValueError` 또는 `ProjectError`로 프로젝트 로드를 거부한다.
4. 정상적인 legacy JSON 프로젝트의 외부 절대경로는 기존처럼 허용한다.
5. reference 모드의 정상 외부 파일 경로도 깨뜨리지 않는다.
6. Windows separator, URL-escaped 형태, 중복 slash, Unicode 경로 등도 테스트한다.
7. ZIP duplicate entry와 대소문자 충돌이 Windows에서 예상치 못한 overwrite를 만들 수 있는지 함께 검토한다.
8. thumbnail과 manifest 외의 ZIP 엔트리는 기존 정책대로 무시하되, 자산 참조 검증과 모순되지 않게 한다.

## 반드시 추가할 테스트

`tests/test_project_service.py`에 최소 다음 케이스를 추가한다.

- manifest: `assets/../../secret.txt`, ZIP 엔트리 없음 -> 로드 거부
- manifest: `assets/../secret.txt` -> 로드 거부
- manifest: `/assets/file.mp3` -> 내부 자산으로 오인하지 않음 또는 명확히 거부
- 정상 `assets/<hash>_track.mp3` + 실제 ZIP entry -> 정상 로드
- manifest가 존재하지 않는 `assets/missing.mp3` 참조 -> 로드 거부
- legacy JSON의 정상 외부 절대경로 -> 기존 동작 유지
- embedded 프로젝트 save -> load round trip 유지
- cancellation, disk-space guard 기존 테스트 유지

## 완료 조건

- package manifest의 내부 자산 참조가 cache root 밖 경로로 탈출할 수 없다.
- 실제 추출되지 않은 `assets/...` 경로를 앱이 로컬 파일로 취급하지 않는다.
- 정상 프로젝트 호환성을 유지한다.
- 전체 테스트 통과.
