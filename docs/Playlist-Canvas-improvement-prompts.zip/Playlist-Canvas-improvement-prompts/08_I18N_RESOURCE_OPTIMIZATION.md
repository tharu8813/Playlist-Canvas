# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

기본 언어팩 참고 파일의 설치/생성 비용과 번역 구조를 정리하라.

## 확인된 구조

`app/services/language_pack_service.py`:

- 첫 기본 directory 사용 시 `ensure_default_files()` 호출
- `ko.json`, `en.json`, `language-pack-template.json`을 사용자 language 폴더로 복사
- 이후 `refresh()`에서는 이 3개 파일을 외부 pack 검색에서 제외

기준 트리 파일 크기:

- `app/resources/ko.json` 약 541 KB
- `app/resources/en.json` 약 533 KB
- `app/resources/language-pack-template.json` 약 878 KB

내장 ko/en 런타임 번역은 `Translator`의 `_TEXT`, literal mapping, Qt translator 등의 별도 경로가 존재한다.
따라서 이 JSON 3개는 런타임 필수 번역 데이터인지, 커뮤니티 번역 참고/템플릿인지 역할을 명확히 해야 한다.

## 목표

기능을 줄이지 않으면서 startup I/O, 배포 크기, 사용자 데이터 중복을 줄이고
언어팩 생성물의 source-of-truth를 명확히 한다.

## 작업

1. 세 JSON 각각이 런타임에 실제 read되는지 호출 그래프로 확인한다.
2. "참고용 파일"이라면 매 첫 실행 자동 복사 대신 아래 중 하나를 검토한다.
   - 설정 화면의 "언어팩 템플릿 내보내기"
   - 필요 시 resource에서 생성/복사
   - 압축 resource + 요청 시 해제
3. 사용자에게 이미 존재하는 파일을 절대 덮어쓰지 않는 현재 정책은 유지한다.
4. 템플릿 생성 스크립트와 실제 UI literal source 간 drift를 검사하는 CI test를 추가한다.
5. 내장 `ko/en`과 외부 pack schema의 placeholder 검증 규칙을 가능한 한 공유한다.
6. `Translator.translate_widget_tree()`가 큰 창에서 모든 child widget/action을 매번 순회하는 비용을 프로파일링한다.
   외부 언어팩 활성화 때만 동작하는 현재 최적화는 유지한다.
7. formatted override regex cache의 rebuild 조건을 검증한다.
8. 1MB pack 제한과 현재 생성 템플릿 크기의 여유가 앞으로 충분한지 테스트로 경고한다.

## 측정

- cold start에서 language service 초기화 시간
- first run copy bytes / elapsed time
- 설치 디렉터리와 사용자 데이터 중복 용량
- 5,000+ override pack 적용 시 top-level window translation 시간

## 완료 조건

- 참고용 리소스를 매번/무조건 다루는 비용이 줄어듦.
- 외부 언어팩 UX와 기존 사용자 파일 호환성 유지.
- generated resource drift를 CI에서 감지.
