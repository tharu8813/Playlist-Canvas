# Playlist Canvas Improvement Prompt Pack

이 ZIP은 `tharu8813/Playlist-Canvas`의 `main` 브랜치를 기준으로 코드 구조와 최근 변경을 감사해 만든
**코드 에이전트용 개선 프롬프트 모음**이다.

기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
작성일: 2026-09-28

## 파일

- `00_AUDIT_SUMMARY.md`: 전체 감사 요약과 우선순위
- `01_PROJECT_PACKAGE_SECURITY.md`: `.pvsproj` 자산 경로 안전성
- `02_QT_WORKER_LIFECYCLE.md`: QThread/worker 종료와 취소 안정성
- `03_UI_ARCHITECTURE_REFACTOR.md`: 대형 UI 클래스 단계적 분해
- `04_AUTOMIX_CACHE_CONCURRENCY.md`: AutoMix cache/concurrency
- `05_AUTOMIX_INVARIANT_TESTING.md`: AutoMix 생성형 회귀 테스트
- `06_EXPORT_PIPE_RELIABILITY.md`: live pipe Export 스트레스/성능
- `07_PREVIEW_FILTER_OBSERVABILITY.md`: Preview filter 진단성
- `08_I18N_RESOURCE_OPTIMIZATION.md`: 언어팩 리소스 최적화
- `09_TEST_CI_OPTIMIZATION.md`: 테스트/CI 속도와 진단 개선
- `10_PROJECT_SCHEMA_MIGRATIONS.md`: 프로젝트 스키마 migration 분리
- `11_DOCS_DEPENDENCY_CONSISTENCY.md`: 문서/의존성/배포 정합성
- `12_MASTER_IMPLEMENTATION_PROMPT.md`: 전체를 순차 수행하는 종합 프롬프트

## 사용법

한 번에 전체를 에이전트에 던지는 것보다 `01`부터 필요 항목을 하나씩 작업시키는 것을 권장한다.
특히 01, 02는 안정성 관련이므로 먼저 검토하고, 03은 큰 리팩터링이므로 별도 branch에서 수행하는 편이 안전하다.

각 프롬프트는 "바로 수정"보다 **현재 HEAD 재검증 -> 테스트/재현 -> 최소 수정 -> 회귀 테스트** 순서를 강제하도록 작성했다.
