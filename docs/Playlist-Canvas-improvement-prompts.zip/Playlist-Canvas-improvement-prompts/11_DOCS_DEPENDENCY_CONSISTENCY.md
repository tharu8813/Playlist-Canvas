# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

README, 의존성 파일, release spec, 실제 구현의 계약을 자동으로 맞춰라.

## 확인된 불일치/혼동 가능 지점

### Export 설명

최근 live Canvas export 구현은 `app/renderer/canvas_pipe.py` 기준으로
각 stream을 named pipe/FIFO를 통해 **final FFmpeg process에 직접 전달**하고,
중간 video file을 만들지 않는 경로가 존재한다.

반면 README 상단/일부 섹션은 "무손실 중간 영상으로 바로 스트리밍",
"중간 영상이 필요" 같은 과거 구조 설명이 섞여 있을 수 있다.

### Sonara

`requirements.txt`는 Sonara를 optional로 설명하고 실제 목록에는 넣지 않는다.
`requirements-lock.txt`는 Windows release environment에 `sonara==0.3.6`을 포함하며
주석은 release specification/CI에서 필요하다고 설명한다.

이 차이는 의도적일 수 있다:
- 소스 최소 의존성: optional
- 공식 Windows release: bundled
하지만 문서에서 그 계약이 명확해야 한다.

## 목표

사용자가 "소스 실행", "공식 배포판", "optional fallback"을 혼동하지 않게 하고,
구현 변경 후 문서가 자동으로 낡는 부분을 줄인다.

## 작업

1. README의 Export pipeline 설명을 실제 `piped_export_supported()`/fallback 구조와 대조해 수정한다.
2. 다음 3개 환경을 dependency table로 명시한다.
   - 최소 source/dev
   - official Windows release lock
   - optional tooling
3. Sonara/onnxruntime/librosa가 없을 때 정확히 어떤 기능이 fallback/disable되는지 코드 기준으로 작성한다.
4. FFmpeg managed install과 custom FFmpeg fallback 요구 codec/filter를 정리한다.
5. `requirements-lock.txt`와 `playlist_canvas.spec`의 핵심 package가 drift하는지 CI check를 검토한다.
6. README version badge/setup filename과 `app.__version__`/release build version drift를 검출하는 작은 script/test를 추가한다.
7. docs에 과거 구현 prompt/history가 남아 있을 경우 "historical" 표시를 확실히 한다.
8. 현재 direct-pipe path와 fallback intermediate path의 temp disk 요구량을 구분한다.

## 완료 조건

- README만 읽어도 source install과 official build 차이를 이해할 수 있음.
- 현재 Export 구조 설명이 코드와 일치.
- 버전/lock/spec 문서 drift 중 자동화 가능한 부분은 CI에서 감지.
