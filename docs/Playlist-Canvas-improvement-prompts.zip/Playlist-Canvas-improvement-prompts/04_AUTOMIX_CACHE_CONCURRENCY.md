# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

AutoMix 캐시의 무제한 메모리 증가와 분석 동시성/취소 경계를 정리하라.

## 확인된 코드

### `app/automix/cache.py`

`_digest_memo`:
`(canonical path, size, mtime_ns) -> SHA-256`

코드 주석 자체가 현재 unbounded cache임을 명시한다.
디스크 분석 캐시도 오래된 analyzer/file entry를 자동 prune하지 않고 수동 clear 전까지 누적된다.

### `app/controllers/progressive_automix_controller.py`

`_LEVELS`:
`(canonical path, size, mtime_ns) -> (LUFS, peak)`

이 캐시도 세션 동안 unbounded다.

또한 `_AnalysisWorker.run()`은 QThread 내부에서 loudness/structure용 Python thread를 추가로 만들고
rhythm analysis와 병렬 수행한 뒤 join한다.

## 목표

일반적인 플레이리스트 성능은 유지하면서 긴 편집 세션, 대량 파일 audition, 파일 버전 변경에서
메모리/디스크 캐시와 분석 thread가 예측 가능한 상한을 갖게 한다.

## 작업

1. `_digest_memo`와 `_LEVELS`를 bounded LRU로 변경한다.
   - 단순 `functools.lru_cache`가 파일 변경 invalidation을 깨지 않는지 검토
   - 현재 `(path,size,mtime_ns)` key 의미 유지
   - 테스트에서 cache size를 조회할 수 있는 최소 diagnostic hook 제공
2. 적절한 상한을 근거와 함께 정한다.
   - 예: 128~512 entries 범위 벤치마크
   - 대형 playlist와 일반 session workload 측정
3. 동일 파일을 여러 worker가 동시에 요청할 때 SHA-256 또는 loudness scan이 중복 실행되는지 확인한다.
   필요하면 per-key single-flight를 적용한다.
4. 전역 lock을 파일 전체 hashing/FFmpeg 실행 시간 동안 잡지 않는다.
5. 디스크 AutoMix cache에 optional prune 정책을 추가한다.
   - 최대 age
   - 최대 total size
   - 최근 사용 순서
   - analyzer/schema가 더 이상 사용되지 않는 entry 우선 제거
6. prune은 UI startup을 블로킹하지 않게 한다.
7. cache clear와 concurrent store가 충돌해도 정상 동작해야 한다.
8. Progressive worker child thread들의 concurrency가 CPU 과포화로 UI와 Export를 방해하지 않는지 측정한다.
   numpy/onnxruntime/librosa 자체 thread pool과 곱해지는 경우 worker 수를 제한한다.

## 테스트

- 1000개의 서로 다른 fake fingerprint 입력 후 메모리 cache 상한 유지
- 같은 key 반복 -> 재계산 없음
- mtime/size 변경 -> 새 digest
- concurrent same-key 호출 -> 결과 정확성, 중복 작업 횟수 검증
- cache clear와 store 경쟁
- prune 중 malformed/temp file 존재
- analyzer version 변경 후 오래된 cache 정리
- cancellation 후 failed/cancelled 결과가 `_LEVELS`에 저장되지 않음

## 측정

수정 전/후 다음을 표로 남긴다.

- 100/500/1000 파일 metadata-only workload의 cache entry 수
- 동일 파일 재오픈 시 hashing 횟수
- peak RSS
- AutoMix 분석 시작부터 첫 partial playable까지 시간
- GUI event-loop latency가 악화되지 않았는지

## 완료 조건

- in-memory cache가 명시된 최대 크기를 넘지 않는다.
- 디스크 cache는 사용자가 방치해도 무한 성장하지 않는 선택적 자동 정리 정책을 가진다.
- 동일 파일 중복 분석 비용이 불필요하게 반복되지 않는다.
- Preview/Export 결과는 기존과 동일하다.
