# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

ProjectDocument의 검증과 스키마 마이그레이션을 명시적 단계로 분리하라.

## 확인된 구조

`app/models/project.py::ProjectDocument.from_dict()`가 현재 한 함수에서 다음을 모두 수행한다.

- root/type/collection validation
- version 1/2 지원
- `automix_enabled` -> `transition_mode` migration
- `automix_preset` 제거
- CanvasSettings 생성/범위 검증
- ProjectSettings 생성/범위 검증
- source/group/playlist/content deserialize
- unique ID 검증
- 참조 무결성 검증
- theme/language 검증
- version 2 object 생성

프로젝트 기능이 빠르게 늘어나면서 manual AutoMix override 같은 필드가 추가되고 있어,
앞으로 migration이 계속 이 함수에 쌓이면 과거 호환성 수정이 어려워질 가능성이 높다.

## 목표

`raw payload -> version migration -> current schema validation -> model construction` 단계를 명확히 분리한다.

## 작업

1. 현재 v1/v2 fixture와 실제 migration behavior를 테스트로 먼저 고정한다.
2. `migrate_project_payload(data)` 계층을 만든다.
   - 입력 dict를 mutate하지 않음
   - v1 -> v2처럼 단계별 pure function
   - 각 단계가 새 dict 반환
3. current schema validation과 migration을 분리한다.
4. unknown future version은 기존처럼 명확히 거부한다.
5. 새 field default 적용은 dataclass `__post_init__`와 migration 중 한 곳이 source-of-truth가 되게 한다.
6. ProjectSettings의 "잘못된 값 clamp"와 ProjectDocument의 "잘못된 값 reject" 정책 차이를 문서화한다.
7. `theme`/`language`처럼 현재 app-wide preference와 legacy project metadata가 섞인 필드를 장기적으로 어떻게 다룰지 명시한다.
8. migration fixture를 version별 JSON 파일로 두고 round-trip test를 만든다.
9. future v3가 필요하지 않다면 억지로 version을 올리지 않는다. 구조만 준비한다.

## 테스트

- v1 fixture -> current model
- v2 fixture -> current model
- input dict 불변
- unknown fields 처리 정책
- future version 거부
- malformed legacy field
- `automix_enabled` migration
- removed `automix_preset`
- current save -> load -> save semantic equality

## 완료 조건

- `from_dict()`가 읽기 쉬운 orchestration 수준으로 줄어듦.
- 과거 버전 migration이 독립 pure test로 검증됨.
- 새 기능 추가 시 기존 migration 로직을 건드릴 범위가 줄어듦.
