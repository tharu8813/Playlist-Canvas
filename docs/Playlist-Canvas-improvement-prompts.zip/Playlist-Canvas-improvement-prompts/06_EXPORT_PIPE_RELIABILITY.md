# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

새 Live Canvas -> FFmpeg named-pipe Export 경로를 스트레스 테스트하고 병목을 계측하라.

## 배경

최근 `app/renderer/canvas_pipe.py`와 ExportSession은 Canvas를 중간 영상 없이 final FFmpeg로 직접 전달한다.

현재 구현의 좋은 점:

- stream별 writer thread
- bounded queue
- Windows named pipe / POSIX FIFO
- cancellable connect/write
- reader closed 처리
- per-stream activity 기반 watchdog
- pipe 실패 시 intermediate fallback
- real FFmpeg integration test 일부 존재

이 경로는 Export 성능의 핵심이므로 "동작한다"보다 장시간/고해상도/여러 layer에서의 안정성이 중요하다.

## 목표

deadlock, stall, runaway memory, 잘못된 fallback, 출력 파일 잔재를 자동으로 검출하고
실제 workload에서 queue/backpressure/CPU 비용을 수치화한다.

## 작업

1. `PipedCanvasStream`에 선택적 diagnostic snapshot을 추가한다.
   - submitted frames/states
   - written frames
   - pending/peak queue
   - last activity
   - connect latency
   - writer error
2. 사용자 로그에 frame 자체나 민감한 path 전체를 덤프하지 않는다.
3. queue capacity를 하드코딩으로 바꾸기 전에 벤치마크한다.
4. 1080p/4K에서 `QImage` copy + pixel conversion peak memory를 측정한다.
5. 여러 Z band가 있을 때 stream 수 증가에 따라 thread 수가 선형 증가하는 비용을 측정한다.
6. final FFmpeg가 한 input을 늦게 open할 때 전체 producer가 안전하게 backpressure되는지 검증한다.
7. reader가 중간에 종료, encoder가 실패, disk full, cancel, app shutdown 각각에서 모든 endpoint/thread/temp output이 정리되는지 확인한다.
8. fallback to intermediate가 시작될 때:
   - pipe worker 완전 종료
   - partial final output 제거
   - storage estimate 재검사
   - progress UI state reset
   를 assert한다.
9. POSIX FIFO 테스트와 Windows named-pipe 테스트를 구분하고 Windows CI coverage를 강화한다.

## 필수 스트레스 테스트

- 30~60분 simulated timeline을 작은 image로 빠르게 feed
- 1 / 5 / 20 static Z bands
- producer가 consumer보다 빠름
- consumer가 producer보다 빠름
- reader가 특정 stream만 멈춤
- connect가 오래 지연됨
- 중간 frame에서 cancel
- FFmpeg process 조기 exit
- exception 후 즉시 재-export
- 동일 앱 세션에서 export 20회 반복

## 벤치마크

`tools/export_pipe_benchmark.py`가 이미 존재한다면 확장한다.

최소 기록:
- wall time
- peak RSS
- temp disk peak
- average/peak queue depth
- capture FPS
- final encode FPS
- fallback 횟수/이유

성능 기준은 절대 숫자만 박지 말고 기준 머신 결과와 상대 회귀 threshold를 같이 기록한다.

## 문서 동기화

README에 여전히 "중간 영상으로 스트리밍"처럼 현재 direct-final-encoder 구조와 다른 설명이 남아 있다면
실제 코드와 정확히 맞게 수정한다.

## 완료 조건

- 정상 path와 failure path 모두 worker/pipe leak 없음.
- 장시간 simulated export에서 memory가 timeline 길이에 비례해 증가하지 않음.
- 실패 후 다음 export가 정상 시작됨.
- benchmark 결과와 regression threshold가 문서화됨.
