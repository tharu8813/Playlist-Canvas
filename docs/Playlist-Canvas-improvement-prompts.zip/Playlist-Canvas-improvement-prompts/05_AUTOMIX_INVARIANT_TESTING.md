# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

AutoMix planner/manual override의 경계값을 생성형 회귀 테스트로 잠가라.

## 배경

최근 커밋에서 이미 다음 실제 경계 버그가 수정됐다.

- track ID에 `>`가 포함되면 override key parsing 문제
- 매우 큰 숫자로 인한 `OverflowError`
- overlap 없는 junction을 manual로 전환할 때 임의 overlap 생성
- drag 중 scale 변화/스냅/경계 처리
- override가 비어 있을 때 settings identity 유지

기능이 빠르게 확장되는 만큼 개별 예제 테스트만으로는 조합 폭발을 잡기 어렵다.

## 목표

"어떤 입력에서도 planner가 지켜야 하는 불변식"을 먼저 정의하고,
deterministic randomized test 또는 Hypothesis 기반 테스트로 수백~수천 조합을 자동 검증한다.

새 dependency 추가가 부담되면 표준 `random.Random(고정 seed)`로 구현한다.

## 필수 불변식

실제 모델 이름/필드에 맞춰 다음을 정교화한다.

1. 모든 transition 시간은 finite다.
2. overlap은 음수가 아니다.
3. transition은 outgoing/incoming clip의 유효 범위를 벗어나지 않는다.
4. output timeline은 역행하지 않는다.
5. disabled track은 transition pair에 끼지 않는다.
6. zero/very-short duration track도 crash하지 않는다.
7. Auto mode에서 manual override가 없는 pair는 automatic planner 결과를 사용한다.
8. reorder 후 pair가 바뀌면 잘못된 override가 다른 junction에 적용되지 않는다.
9. serialize -> parse -> serialize가 canonical하고 안정적이다.
10. track ID는 `>`, Unicode, whitespace, 매우 긴 문자열 등에서도 key collision이 없다.
11. NaN, inf, 매우 큰 수, bool-as-int 입력은 안전하게 reject/clamp된다.
12. Preview와 Export에 전달되는 resolved settings/plan은 동일한 입력에서 동일해야 한다.
13. Custom EQ band windows는 겹침 범위 밖으로 나가지 않고 empty/degenerate 상태를 명확히 처리한다.
14. tempo match/ramp가 0 또는 비정상 BPM에서 divide-by-zero를 만들지 않는다.

## 작업

- `app/automix/overrides.py`
- planner 관련 모듈
- transition model
- manual planner
- render plan conversion
- project serialization
을 함께 감사한다.

테스트에서 private implementation detail보다는 public planning/serialization contract를 호출한다.

## 회귀 corpus

random test가 실패하면 seed와 최소 입력을 `tests/data` 또는 명시적인 regression test로 고정한다.
한 번 발견한 crash input은 랜덤 테스트에만 남기지 않는다.

## 완료 조건

- 최소 수백 개의 deterministic generated cases가 CI에서 매번 실행된다.
- 기존 recent edge case를 모두 명시적 test로 보존한다.
- crash가 아닌 "정상 fallback"이어야 하는 입력은 fallback contract를 assert한다.
- 테스트 실행시간이 과도하게 늘어나지 않는다.
