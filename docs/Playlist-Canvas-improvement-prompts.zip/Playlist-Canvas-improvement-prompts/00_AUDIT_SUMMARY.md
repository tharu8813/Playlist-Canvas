# Playlist Canvas 코드 감사 요약

> 저장소: `tharu8813/Playlist-Canvas`  
> 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 분석일: 2026-09-28

## 목적

현재 Playlist Canvas의 구조, 최근 변경 흐름, 안정성 코드, 테스트, AutoMix, Export, 프로젝트 파일 처리,
국제화 리소스를 살펴보고 **지금 시점에서 추가로 개선할 가치가 큰 항목**을 우선순위화했다.

## 확인된 프로젝트 특징

- Windows 중심 Python 3.12 + PySide6 데스크톱 편집기.
- Preview와 Export가 같은 렌더/AutoMix 계획을 공유하려는 구조가 이미 자리잡아 있다.
- 최근 커밋에서 AutoMix 수동 전환, Custom EQ, Preview 전환 편집기, Canvas 실시간 파이프 Export가 빠르게 추가됐다.
- Windows `0xC0000409` QThread 종료 크래시를 고친 전용 헬퍼와 아키텍처 회귀 테스트가 이미 존재한다.
- 테스트는 각 `test_*.py` 모듈을 독립 프로세스로 실행해 Qt 상태 누수를 차단한다.
- `.pvsproj`는 ZIP 기반 휴대형 프로젝트이며 미디어를 임베드할 수 있다.

## 우선순위

| 우선순위 | 항목 | 이유 |
|---|---|---|
| P0 | 프로젝트 패키지 자산 경로 검증 강화 | 악성/손상 manifest가 `assets/../../...` 같은 미추출 경로를 로컬 경로로 해석할 여지를 제거 |
| P0 | Qt/QThread 종료 및 취소 계약 통합 | 과거 실제 Windows 크래시 이력이 있고 일부 동기 작업 경로는 별도 wait/deleteLater 흐름 사용 |
| P1 | 거대 UI 클래스 단계적 분해 | `main_window.py` 약 246 KB, `export_preview_dialog.py` 약 179 KB 등 변경 충돌과 회귀 위험이 큼 |
| P1 | AutoMix 메모리 캐시/동시성 정리 | `_digest_memo`, `_LEVELS`가 세션 동안 무제한 증가하며 분석 worker 내부에 별도 Python thread가 존재 |
| P1 | AutoMix 불변식/경계값 회귀 테스트 | 최근 track ID 특수문자, 큰 숫자, manual junction 등 경계 버그가 실제로 수정된 이력 |
| P1 | Live Export 파이프 스트레스/성능 검증 | 새 named-pipe 경로는 효율적이지만 플랫폼별 I/O, backpressure, fallback이 핵심 위험 구간 |
| P2 | Preview 영상 필터 오류 관측성 | frame filter worker가 모든 예외를 조용히 빈 `QImage`로 바꿔 원인 추적이 어려움 |
| P2 | i18n 기본 리소스 설치 최적화 | 기본 JSON 3개가 첫 실행에 복사되며 파일 크기가 큼. 실제 내장 번역 경로와 역할 분리 검토 필요 |
| P2 | 테스트/CI 실행시간 최적화 | 모든 테스트 모듈을 독립 프로세스로 직렬 실행. 격리 이점은 유지하면서 안전한 병렬화 여지 |
| P2 | 프로젝트 스키마 마이그레이션 계층화 | `ProjectDocument.from_dict()`에 검증과 과거 필드 마이그레이션이 계속 누적되는 형태 |
| P2 | 문서/의존성/배포 계약 정합성 | Export 구조와 Sonara 설치 정책 등 소스 실행/릴리스 문서가 최신 구현과 계속 맞도록 자동 점검 필요 |

## 큰 파일/책임 집중 구간

기준 트리에서 확인한 대표 파일 크기:

- `app/ui/main_window.py` 약 246 KB
- `app/dialogs/export_preview_dialog.py` 약 179 KB
- `app/canvas/source_item.py` 약 106 KB
- `app/inspector/source_inspector.py` 약 108 KB
- `app/renderer/ffmpeg_renderer.py` 약 95 KB
- `app/controllers/export_controller.py` 약 88 KB
- `app/widgets/transition_inspector.py` 약 88 KB
- `tests/test_functional_regressions.py` 약 116 KB
- `tests/test_main_window_preview.py` 약 119 KB
- `tests/test_main_window.py` 약 105 KB

파일 크기 자체를 목표로 줄이지 말고 **책임, 상태 소유권, 테스트 경계**를 기준으로 나눈다.

## 최근 수정이라 다시 깨뜨리면 안 되는 영역

- `6192213`: Canvas를 final FFmpeg encoder로 직접 스트리밍하는 live pipe 경로
- `460ac86`: pipe stall watchdog, fallback 저장공간 재검사, Windows `ERROR_PIPE_CONNECTED` 처리
- `9eebba6`: Settings dialog의 lambda 수명으로 인한 종료 크래시 수정
- `ae84d19` ~ `962c689`: manual AutoMix junction, Custom EQ, 드래그/스냅 UX 개선
- `tests/test_architecture.py`: MainWindow 역참조 금지, QThread DeferredDelete 중앙화 등 아키텍처 방어선

## 권장 실행 순서

1. `01_PROJECT_PACKAGE_SECURITY.md`
2. `02_QT_WORKER_LIFECYCLE.md`
3. `03_UI_ARCHITECTURE_REFACTOR.md`
4. `04_AUTOMIX_CACHE_CONCURRENCY.md`
5. `05_AUTOMIX_INVARIANT_TESTING.md`
6. `06_EXPORT_PIPE_RELIABILITY.md`
7. `07_PREVIEW_FILTER_OBSERVABILITY.md`
8. `08_I18N_RESOURCE_OPTIMIZATION.md`
9. `09_TEST_CI_OPTIMIZATION.md`
10. `10_PROJECT_SCHEMA_MIGRATIONS.md`
11. `11_DOCS_DEPENDENCY_CONSISTENCY.md`

각 문서는 독립적으로 실행 가능하지만, 1~2번은 안정성 측면에서 먼저 처리하는 편이 좋다.
