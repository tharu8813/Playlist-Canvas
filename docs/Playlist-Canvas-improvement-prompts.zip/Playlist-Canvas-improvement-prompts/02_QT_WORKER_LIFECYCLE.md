# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

Qt worker/QThread의 종료, 취소, deleteLater 소유권을 하나의 명시적 계약으로 통합하라.

## 배경

프로젝트에는 `app/utils/qt_worker_lifecycle.py::stop_qthread_now()`가 있으며,
주석과 `tests/test_architecture.py`에 따르면 실제 Windows `0xC0000409` fail-fast 크래시를 해결한 검증된 종료 순서다.

동시에 다음 경로를 확인해야 한다.

- `app/controllers/preview_audio_controller.py::prepare_audio_for_ui()`
  - 자체 `QEventLoop`
  - `worker.wait()`
  - `worker.deleteLater()`
- `PreviewAudioController.shutdown()`
  - `stop_qthread_now()` 사용
- `ProgressiveAutoMixController.shutdown()`
  - analysis/render QThread에 `stop_qthread_now()` 사용
- `_AnalysisWorker.run()`
  - 내부에서 Python `threading.Thread`를 추가로 시작하고 `join()`함
- 여러 signal lambda가 worker 또는 owner를 캡처

## 목표

"누가 worker를 소유하고, 누가 취소하고, 누가 wait/delete를 수행하는가"가 모든 경로에서 일관되게 보장되도록 한다.
단, 검증된 `stop_qthread_now()`의 동작을 성급하게 단순화하지 않는다.

## 작업

1. 저장소 전체에서 다음 패턴을 감사한다.
   - `QThread(`
   - `.start()`
   - `.wait(`
   - `.deleteLater()`
   - nested `QEventLoop`
   - `finished.connect(lambda`
   - Python `threading.Thread(...).join()`
2. 각 worker마다 owner, cancel token, finish receiver, deletion owner를 표로 정리한다.
3. `prepare_audio_for_ui()` 같은 동기 helper가 공통 lifecycle 규약을 우회하는지 검증한다.
4. 공통 helper가 필요한 경우:
   - "이미 finished된 worker 정리"
   - "running worker 취소 후 정리"
   - "nested loop로 기다리는 sync helper"
   를 분리된 API로 만들되 DeferredDelete 순서는 한 곳에서만 유지한다.
5. `stop_qthread_now()`의 `worker.finished.disconnect()`가 모든 receiver를 제거하는 동작이 필요한 이유를 테스트로 고정한다.
   가능하면 connection ownership을 명시해 과도한 disconnect를 피하되, 기존 크래시 재발 가능성이 있으면 현재 동작을 유지한다.
6. `_AnalysisWorker` 안의 child `threading.Thread`들이 외부 라이브러리 정지 실패 시 무기한 `join()`을 유발할 수 있는지 확인한다.
   - cancellation contract 강화
   - bounded join + 로그
   - 또는 동일 QThread 안에서 안전한 executor 사용
   중 실제 코드에 맞는 최소 변경을 선택한다.
7. shutdown 중 queued signal이 새 generation에 도달하지 않는지 검증한다.
8. QObject/QThread wrapper가 interpreter shutdown까지 살아남는 참조 사이클을 점검한다.

## 회귀 테스트

- Preview를 열고 즉시 닫기 50회
- AutoMix 분석 시작 직후 닫기 반복
- partial render 중 닫기
- final mix 준비 중 닫기
- Export/Preview/Settings worker가 동시에 살아있는 상태에서 MainWindow 종료
- cancel 직후 `finished`가 같은 이벤트 루프 tick에서 도착하는 race
- 이미 C++ object가 삭제된 wrapper에 shutdown 호출
- worker completion callback이 owner 삭제 이후 queued 되어 있는 케이스

가능한 테스트는 offscreen Qt로 자동화하고, Windows 전용 fail-fast 재현 테스트는 별도 integration 테스트로 분리한다.

## 완료 조건

- raw wait/deleteLater 패턴이 남아 있다면 왜 안전한지 코드 주석과 테스트로 증명된다.
- 모든 장기 worker가 명시적인 cancel/shutdown 경로를 가진다.
- 종료 시 hang, double-delete, use-after-delete, queued stale result가 재현되지 않는다.
- `tests/test_architecture.py`의 기존 방어선을 유지 또는 강화한다.
