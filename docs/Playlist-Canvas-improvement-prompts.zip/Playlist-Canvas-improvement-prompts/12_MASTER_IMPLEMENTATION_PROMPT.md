# Playlist Canvas 종합 개선 실행 프롬프트

> 대상: `tharu8813/Playlist-Canvas`  
> 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`

당신은 시니어 Python/PySide6 데스크톱 엔지니어다.
이 저장소의 안정성, 유지보수성, 성능을 개선하되 최근의 AutoMix/Export 기능을 회귀시키지 않는 것이 목표다.

## 시작 전에

1. 현재 HEAD와 `962c6893bab6937f4b6da872225858b51ae7f5a6` 이후 커밋을 확인한다.
2. `00_AUDIT_SUMMARY.md`와 01~11 프롬프트를 읽는다.
3. 이미 해결된 항목은 건너뛰고 이유를 기록한다.
4. 모든 변경을 한 번에 섞지 말고 아래 순서로 작은 commit/PR 단위로 진행한다.

## 실행 순서

### Phase A: 안정성
1. 프로젝트 패키지 내부 자산 경로 검증
2. QThread/worker 종료 및 취소 계약 감사

### Phase B: 핵심 구조
3. MainWindow/PreviewDialog 책임 분해 1차
4. Project schema migration 계층화

### Phase C: AutoMix
5. bounded cache/single-flight/concurrency 점검
6. planner/manual override invariant generated tests

### Phase D: Export/Preview
7. live pipe 스트레스 테스트와 벤치마크
8. video frame filter 오류 관측성

### Phase E: 개발 경험/배포
9. i18n resource 설치 최적화
10. test runner/CI 안전 병렬화
11. 문서/의존성 계약 정합성

## 절대 지켜야 할 것

- `tests/test_architecture.py`가 보호하는 경계를 우회하지 않는다.
- verified QThread DeferredDelete 순서를 근거 없이 바꾸지 않는다.
- Preview와 Export의 AutoMix plan/audio timing을 따로 계산하게 만들지 않는다.
- 새 기능을 위해 MainWindow에 worker runtime state를 다시 넣지 않는다.
- live pipe 실패 시 기존 fallback을 제거하지 않는다.
- broad exception을 기계적으로 전부 없애지 않는다. worker/process boundary의 예외 격리 목적을 보존한다.
- 리팩터링과 UI 디자인 변경을 같은 commit에 섞지 않는다.

## 각 Phase의 산출물

- 변경 이유
- 재현 또는 코드 근거
- 수정 파일
- 추가한 테스트
- 실행한 test command
- 성능 변경이면 before/after
- 남은 위험
- rollback 포인트

## 최종 검증

최소:
```bash
python -m compileall -q main.py app tests scripts
python scripts/run_tests.py
```

가능하면 Windows에서 PyInstaller distribution verification과 packaged smoke test까지 실행한다.

최종 보고서는 "무엇을 많이 고쳤는가"보다
"어떤 위험을 어떤 테스트로 제거했는가" 중심으로 작성한다.
