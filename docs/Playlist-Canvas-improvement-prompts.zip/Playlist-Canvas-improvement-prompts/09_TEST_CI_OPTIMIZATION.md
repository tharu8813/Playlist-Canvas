# Playlist Canvas 개선 작업 프롬프트

> 대상 저장소: `tharu8813/Playlist-Canvas`  
> 기준 브랜치: `main`  
> 분석 기준 커밋: `962c6893bab6937f4b6da872225858b51ae7f5a6`  
> 작성 기준일: 2026-09-28

이 문서는 코드 에이전트(Claude Code, Codex 등)에 그대로 전달할 수 있는 실행 프롬프트다.
저장소 최신 상태가 기준 커밋보다 앞서 있다면, 먼저 현재 구현과 최근 커밋을 다시 확인하고 이미 해결된 항목은 중복 수정하지 않는다.

## 공통 원칙

- 수정 전에 관련 코드와 테스트를 실제로 읽고, 문제를 재현하거나 코드 경로로 검증한다.
- 최근 안정화 작업을 되돌리지 않는다.
- 단순한 "정리"를 위해 동작을 바꾸지 않는다.
- GUI 스레드를 블로킹하는 I/O, FFmpeg, 분석 작업을 새로 만들지 않는다.
- Qt 객체의 소유권과 종료 순서를 명시적으로 유지한다.
- Preview와 Export의 타이밍/오디오 결과가 갈라지지 않게 한다.
- 새로운 회귀 테스트를 먼저 또는 수정과 동시에 추가한다.
- 최종적으로 `python scripts/run_tests.py`를 실행한다.
- Windows 전용 동작을 수정한 경우 가능한 범위에서 Windows CI 또는 대응 테스트를 추가한다.
- 성능 개선은 추측이 아니라 측정 전/후 결과로 증명한다.

## 작업명

Qt 격리는 유지하면서 테스트/CI 피드백 시간을 줄이고 실패 진단을 개선하라.

## 현재 구조

`.github/workflows/deployment.yml`:

- Windows latest
- locked dependencies
- compileall
- `python scripts/run_tests.py`
- PyInstaller build
- distribution verification
- packaged app smoke test
- job timeout 30분

`scripts/run_tests.py`:

- 모든 `tests/test_*.py`를 정렬
- 각 모듈을 새로운 Python process에서 실행
- 모듈당 timeout 기본 180초
- 전체는 직렬 실행

이 격리는 Qt Multimedia/worker thread 상태 누수를 차단하기 위한 의도적인 설계이므로 없애면 안 된다.

## 목표

격리 수준은 유지하되 안전한 범위에서 병렬 실행, test tiering, failure artifact를 도입해 PR 피드백을 빠르게 한다.

## 작업

1. 각 테스트 모듈의 실행시간을 측정하고 JSON/텍스트 리포트를 생성한다.
2. 테스트를 자동 또는 명시적으로 분류한다.
   - pure unit/no Qt
   - Qt offscreen
   - real FFmpeg optional integration
   - Windows lifecycle
   - packaging smoke
3. 독립 프로세스 모델을 유지한 채 `--jobs N` 병렬 옵션을 추가한다.
4. 전역 OS resource, fixed temp path, shared QSettings, port/pipe 이름 충돌 가능성이 있는 모듈은 serial group으로 둔다.
5. 기본 local runner는 CPU 수를 그대로 쓰지 말고 conservative cap을 둔다.
6. CI를 가능하면:
   - fast tests
   - packaging/integration
   로 job 분리해 빠른 실패를 먼저 보여준다.
7. timeout 시 stdout/stderr, module runtime, process exit code를 artifact로 남긴다.
8. flaky race test는 재시도로 숨기지 말고 반복 stress mode(`--repeat`)를 별도 제공한다.
9. 큰 `test_main_window*` 파일은 기능 영역별 fixture/helper를 공유하면서 나눌 수 있는지 검토한다.
10. coverage 숫자 자체를 목표로 삼지 말고 다음 critical path만 branch coverage를 확인한다.
   - project save/load
   - worker shutdown
   - Export fallback
   - AutoMix planning/serialization

## 검증

- 기존 serial mode 결과와 parallel mode 결과가 동일
- 같은 테스트를 20회 반복해 order-dependent failure 없음
- CI wall time 비교
- CPU/RAM 과포화 때문에 오히려 느려지지 않는 jobs 기본값 결정

## 완료 조건

- Qt process isolation 보존.
- PR fast feedback 시간이 유의미하게 감소.
- 실패/timeout 원인 확인이 쉬워짐.
- packaging smoke test는 최종 gate로 계속 유지.
